//
//  main.cpp
//  Project4test
//
//  Created by BRUCE CHANG on 11/22/19.
//  Copyright © 2019 BRUCE CHANG. All rights reserved.
//

#define GL_SILENCE_DEPRECATION
#ifdef WIN32
#include <windows.h>
#endif

#if defined (__APPLE__) || defined(MACOSX)
#include <OpenGL/gl.h>
//#include <OpenGL/glu.h>
#include <GLUT/glut.h>

#else //linux
#include <GL/gl.h>
#include <GL/glut.h>
#endif

#include <GL/glui.h>

//other includes
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <time.h>

using namespace std;

#define PI acos(-1)


class Point
{
public:
    Point();
    GLfloat x,y;
};
Point::Point()
{
    x=0;
    y=0;
}

class Curve
{
public:
    Curve();
    int number_points;
    int resolution;
    Point *ControlPoints;
    Point **deCaTable;
    Point *OutputPoints;
    void update();
    void add_head(float x,float y);
    void delete_point(int delete_j);
    void insert_point(int insert_j);
};

void ControlPointsInput(Point *(*ControlP), int num_points)
{
//    GLint ** ControlPoints;
//    ControlPoints = new GLint *[n];
//    for(int i=0;i<n;i++)
//        ControlPoints[i] = new GLint[n];
    (*ControlP) = new Point [30];
//    for(int i=0;i<num_points;i++)
//    {
//        cout<<"Input Point "<<(i+1)<<":"<<endl;
//        cout<<"x = ";
//        cin>>(*ControlP)[i].x;
//        cout<<"y = ";
//        cin>>(*ControlP)[i].y;
//
//    }
    
}

void deCasteljauTable(Point **(*deCastelT),int num_points)
{
    (*deCastelT) = new Point *[30];
    for(int i=0;i<30;i++)
        (*deCastelT)[i] = new Point[30];
}

Point CompudeCa(Point *(*ControlP),Point **(*deCastelT),int num_points,float u)
{
    for(int i=0;i<num_points;i++)
    {
        (*deCastelT)[0][i].x = (*ControlP)[i].x;
        (*deCastelT)[0][i].y = (*ControlP)[i].y;
    }
    for(int i=1;i<num_points;i++)
        for(int j=0;j<num_points-i;j++)
        {
//            cout<<u<<endl;
//            cout<<i<<'\t'<<j<<'\t'<<(*deCastelT)[i-1][j].x<<'\t'<<(*deCastelT)[i-1][j+1].x<<endl;
            (*deCastelT)[i][j].x = (1-u) * (*deCastelT)[i-1][j].x + u * (*deCastelT)[i-1][j+1].x;
            (*deCastelT)[i][j].y = (1-u) * (*deCastelT)[i-1][j].y + u * (*deCastelT)[i-1][j+1].y;
//            cout<<i<<'\t'<<j<<'\t'<<(*deCastelT)[i][j].x<<'\t'<<(*deCastelT)[i][j].y<<endl;
        }
    return (*deCastelT)[(num_points-1)][0];
}

Curve::Curve()
{
//    cout<<"Input number of control points"<<endl;
//    cin>>number_points;
//    cout<<"Input curve resolution"<<endl;
//    cin>>resolution;
    ControlPointsInput((&ControlPoints), number_points);
//    for(int i=0;i<number_points;i++)
//        cout<<ControlPoints[i].x<<'\t'<<ControlPoints[i].y<<endl;
    deCasteljauTable((&deCaTable), number_points);
//    OutputPoints = new Point [(resolution+1)];
//    for(int i = 0;i<(resolution+1);i++)
//    {
////        cout<<CompudeCa((&ControlPoints), (&deCaTable), number_points, (i/resolution)).x<<'\t'<<CompudeCa((&ControlPoints), (&deCaTable), number_points, (i/resolution)).y<<endl;
//        OutputPoints[i].x = CompudeCa((&ControlPoints), (&deCaTable), number_points, (float(i)/resolution)).x;
//        OutputPoints[i].y = CompudeCa((&ControlPoints), (&deCaTable), number_points, (float(i)/resolution)).y;
//    }
    
}

void Curve::update()
{
    OutputPoints = new Point [(resolution+1)];
    for(int i = 0;i<(resolution+1);i++)
        {
  
            OutputPoints[i].x = CompudeCa((&ControlPoints), (&deCaTable), number_points, (float(i)/resolution)).x;
            OutputPoints[i].y = CompudeCa((&ControlPoints), (&deCaTable), number_points, (float(i)/resolution)).y;
        }
}

void Curve::add_head(float x,float y)
{
    if((ControlPoints[0].x!= x)&&(ControlPoints[0].y!=y))
    {
        for(int i=number_points;i>0;i--)
            ControlPoints[i] = ControlPoints[i-1];
        number_points++;
        ControlPoints[0].x = x;
        ControlPoints[0].y = y;
        update();
    }
    
}

void Curve::delete_point(int delete_j)
{
    if(delete_j<number_points)
    {
        for(int i=delete_j;i<number_points-1;i++)
            ControlPoints[i] = ControlPoints[i+1];
        number_points--;
        update();
    }
}
void Curve::insert_point(int insert_j)
{
    if(insert_j<number_points-1)
    {
        for(int i=number_points;i>insert_j+1;i--)
            ControlPoints[i] = ControlPoints[i-1];
        ControlPoints[insert_j+1].x = (ControlPoints[insert_j].x+ControlPoints[insert_j+2].x)/2;
        ControlPoints[insert_j+1].y = (ControlPoints[insert_j].y+ControlPoints[insert_j+2].y)/2;
        number_points++;
        update();
    }
}



class B_Spine_Curve
{
public:
    B_Spine_Curve();
    int num_control_points;
    int order_k;
    int n_plus_k;
    int resolution;
    float *u_knot;
    Point *ControlPoints;
    Point ***deBoTable;
    Point **OutputPoints;
    void ControlPointsInput();
    void initial_u_knot();
    void initial_deBoTable();
    void update();
    Point Compute(int r_order,int p);
    void add_head(float x,float y);
    void delete_point(int delete_j);
    void insert_point(int insert_j);
    void update_u_knot();
//    void update();
//    void add_head(float x,float y);
//    void delete_point(int delete_j);
//    void insert_point(int insert_j);
};

B_Spine_Curve::B_Spine_Curve()
{
//    cout<<"Input number of control points"<<endl;
//    cin>>num_control_points;
//    cout<<"Input curve resolution"<<endl;
//    cin>>resolution;
    ControlPointsInput();
    order_k = 3;
    initial_deBoTable();
    OutputPoints = new Point *[60];
    for(int p=0;p<60;p++)
        OutputPoints[p] = new Point[101];
    u_knot = new float [120];
//    cout<<"n_plus_k"<<n_plus_k<<endl;
//    initial_u_knot();
//    initial_deBoTable();
//    update();
}

void B_Spine_Curve::ControlPointsInput()
{
    ControlPoints = new Point [60];
//    for(int i=0;i<num_control_points;i++)
//    {
//        cout<<"Input Point "<<(i+1)<<":"<<endl;
//        cout<<"x = ";
//        cin>>ControlPoints[i].x;
//        cout<<"y = ";
//        cin>>ControlPoints[i].y;
//    }
}


void B_Spine_Curve::initial_u_knot()
{
    for(int i=0;i<n_plus_k;i++)
        u_knot[i] = 1/(float(n_plus_k-1))*i;
//    cout<<u_knot[1]<<endl;
}


void B_Spine_Curve::initial_deBoTable()
{
    deBoTable = new Point ** [60];
    for(int i=0;i<60;i++)
    {
        deBoTable[i] = new Point *[60];
        for(int j=0;j<60;j++)
            deBoTable[i][j] = new Point[60];
    }
    
}

Point B_Spine_Curve::Compute(int r_order,int p)
{
        for(int n=p;n<(order_k+p);n++)
            deBoTable[p][0][n] = ControlPoints[n];
    
        float u = u_knot[order_k-1+p] + (u_knot[order_k+p]-u_knot[order_k-1+p])/resolution*r_order;
//    cout<<u<<endl;
        for(int m=1;m<order_k;m++)
            for(int n=p;n<(order_k+p-m);n++)
            {
                deBoTable[p][m][n].x = (u_knot[n+order_k]-u)/(u_knot[n+order_k]-u_knot[m+n])*deBoTable[p][m-1][n].x + (u-u_knot[n+m])/(u_knot[n+order_k]-u_knot[m+n])*deBoTable[p][m-1][n+1].x;
                deBoTable[p][m][n].y = (u_knot[n+order_k]-u)/(u_knot[n+order_k]-u_knot[m+n])*deBoTable[p][m-1][n].y + (u-u_knot[n+m])/(u_knot[n+order_k]-u_knot[m+n])*deBoTable[p][m-1][n+1].y;
            }

//    cout<<deBoTable[p][order_k-1][p].x<<'\t'<<deBoTable[p][order_k-1][p].y<<endl;
    return deBoTable[p][order_k-1][p];
        
}

void B_Spine_Curve::update()
{
    n_plus_k = order_k + num_control_points;
    initial_u_knot();
    for(int p=0;p<(num_control_points-order_k+1);p++)
        for(int i=0;i<resolution+1;i++)
        {
            OutputPoints[p][i] = Compute(i, p);
        }
//    for(int i=0;i<30;i++)
//    {
//        for(int j=0;j<30;j++)
//            delete [] deBoTable[i][j];
//        delete [] deBoTable[i];
//    }
//    delete [] deBoTable;
}

void B_Spine_Curve::add_head(float x,float y)
{
    if((ControlPoints[0].x!= x)&&(ControlPoints[0].y!=y))
    {
//        for(int p=0;p<(num_control_points-order_k+1);p++)
//            delete [] OutputPoints[p];
//        delete [] OutputPoints;
        for(int i=num_control_points;i>0;i--)
            ControlPoints[i] = ControlPoints[i-1];
        num_control_points++;
        ControlPoints[0].x = x;
        ControlPoints[0].y = y;
        update();
    }
    
}

void B_Spine_Curve::delete_point(int delete_j)
{
    if(delete_j<num_control_points)
    {
//        for(int p=0;p<(num_control_points-order_k+1);p++)
//            delete [] OutputPoints[p];
//        delete [] OutputPoints;
        for(int i=delete_j;i<num_control_points-1;i++)
            ControlPoints[i] = ControlPoints[i+1];
        num_control_points--;
        update();
    }
}

void B_Spine_Curve::insert_point(int insert_j)
{
    if(insert_j<num_control_points-1)
    {
//        for(int p=0;p<(num_control_points-order_k+1);p++)
//            delete [] OutputPoints[p];
//        delete [] OutputPoints;
        for(int i=num_control_points;i>insert_j+1;i--)
            ControlPoints[i] = ControlPoints[i-1];
        ControlPoints[insert_j+1].x = (ControlPoints[insert_j].x+ControlPoints[insert_j+2].x)/2;
        ControlPoints[insert_j+1].y = (ControlPoints[insert_j].y+ControlPoints[insert_j+2].y)/2;
        num_control_points++;
        update();
    }
}

void B_Spine_Curve::update_u_knot()
{
    
    for(int p=0;p<(num_control_points-order_k+1);p++)
        for(int i=0;i<resolution+1;i++)
        {
            OutputPoints[p][i] = Compute(i, p);
        }
//    for(int i=0;i<30;i++)
//    {
//        for(int j=0;j<30;j++)
//            delete [] deBoTable[i][j];
//        delete [] deBoTable[i];
//    }
//    delete [] deBoTable;
}




int width=200;
int length=200;
float pixel_size;
int win_width=800;
int win_height=800;

float hit_pos_x,hit_pos_y;
float move_pos_x,move_pos_y;
int button_kind = -1;

Curve *All_curve;
B_Spine_Curve *All_B_curve;
int num_curves;
int num_B_curves;

int move_sign_i=-1;
int move_sign_j=-1;

int Bezier_op = 0;
int insert_hit =0;
int insert_B_hit =0;

int B_Spine_op = 0;

int show_curve = 0;
int show_control_point = 0;
int show_line_segments = 0;
int show_curve_2 = 0;
int show_control_point_2 = 0;
int show_line_segments_2 = 0;
int show_B_curve = 0;
int show_B_control_point = 0;
int show_B_line_segments = 0;

GLUI_Spinner *order_k_B_spinner;
GLUI_Spinner *u_knot_spinner[20];
GLUI *gluiB1;
GLUI_Button *open_adjust_window;
GLUI *gluiB2;

string File_Address;

void mouse_hit(int button,int state,int x,int y)
{
    button_kind = button;
    if(button == GLUT_LEFT_BUTTON)
    {
        if(state == GLUT_DOWN)
        {
//            if((Bezier_op!=0)&&(B_Spine_op!=0))
//            {
                hit_pos_x = float(x)/win_width*width;
                hit_pos_y = length-(float(y)/win_height*length);
//            }
        }
    }
}

void mouse_move(int x,int y)
{
    button_kind = 3;
    move_pos_x = float(x)/win_width*width;
    move_pos_y = length-(float(y)/win_height*length);
//    printf("asdf\n");
}

void control_cb(int control)
{
    B_Spine_op = 0;
    Bezier_op = 0;
    if(control == 1)
    {
        Bezier_op = 1;
    }
    if(control == 2)
    {
        Bezier_op = 2;
        hit_pos_x = -1;
        hit_pos_y = -1;
    }
    if(control == 3)
    {
        Bezier_op = 3;
        hit_pos_x = -1;
        hit_pos_y = -1;
    }
    if(control == 4)
    {
        Bezier_op = 4;
    }
    if(control == 5)
    {
        Bezier_op = 5;
        insert_hit = 1;
    }
    if(control == 6)
    {
        All_curve[0].update();
    }
    if(control == 7)
    {
        Bezier_op = 7;
        hit_pos_x = -1;
        hit_pos_y = -1;
    }
    if(control == 8)
    {
        Bezier_op = 8;
        hit_pos_x = -1;
        hit_pos_y = -1;
    }
    if(control == 9)
    {
        All_curve[1].update();
    }
    
    glutPostRedisplay();
}

void control_B_Spine(int control)
{
    B_Spine_op = 0;
    Bezier_op = 0;
    if(control == 1)
    {
        B_Spine_op = 1;
    }
    if(control == 2)
    {
        B_Spine_op = 2;
        hit_pos_x = -1;
        hit_pos_y = -1;
    }
    if(control == 3)
    {
        B_Spine_op = 3;
        hit_pos_x = -1;
        hit_pos_y = -1;
    }
    if(control == 4)
    {
        B_Spine_op = 4;
    }
    if(control == 5)
    {
        B_Spine_op = 5;
        insert_B_hit = 1;
    }
    if(control == 6)
    {
        All_B_curve[0].update();
    }
    if(control == 7)
    {
        All_B_curve[0].update();
    }
    if(control == 8)
    {
        All_B_curve[0].update_u_knot();
        for(int i=1;i<All_B_curve[0].n_plus_k-1;i++)
            {
                u_knot_spinner[i]->set_float_limits((All_B_curve[0].u_knot[i-1]+0.01), (All_B_curve[0].u_knot[i+1]-0.01));
            }
    }
    
    glutPostRedisplay();
}

void open_adjust_knot_window(int control)
{
    if(control == 1)
    {
        control = 0;
        gluiB1->disable();
        gluiB2 = GLUI_Master.create_glui("B-SPINE-KNOT-ADJUST",0);
        GLUI_Panel *panel_B_knot = new GLUI_Panel(gluiB2,"B-SPINE-KNOT-ADJUST",GLUI_PANEL_EMBOSSED);
            for(int i=1;i<All_B_curve[0].n_plus_k-1;i++)
            {
                u_knot_spinner[i] = new GLUI_Spinner(panel_B_knot,"*",GLUI_SPINNER_FLOAT,&All_B_curve[0].u_knot[i],8,control_B_Spine);
                u_knot_spinner[i]->set_float_limits(((All_B_curve[0].u_knot[i-1]+All_B_curve[0].u_knot[i])/2), ((All_B_curve[0].u_knot[i+1]+All_B_curve[0].u_knot[i])/2));
        //        u_knot_spinner[i]->set_speed(0.01);
            }
        new GLUI_Button(panel_B_knot, "Close", 2,open_adjust_knot_window );
    }
    if (control == 2) {
        control = 0;
        gluiB1->enable();
        open_adjust_window->enable();
        gluiB2->close();
    }
}

void draw_curve()
{
    glClear(GL_COLOR_BUFFER_BIT);
    //glViewport(0, 0, win_width, win_height);
    
    if(show_curve == 1)
    {
    //curve
        glColor3f(0, 1, 0);
        glBegin(GL_LINES);
        int i=0;
            for(int j=0;j<All_curve[i].resolution;j++)
            {
//            cout<<All_curve[i].OutputPoints[j].x<<endl;
                GLfloat point1[ ] = {All_curve[i].OutputPoints[j].x,All_curve[i].OutputPoints[j].y};
                GLfloat point2[ ] = {All_curve[i].OutputPoints[j+1].x,All_curve[i].OutputPoints[j+1].y};
                glVertex2fv (point1);
                glVertex2fv (point2);
                
            }
        glEnd();
    }
    
    if(show_line_segments == 1)
    {
    //control Line
    glColor3f(1, 0, 0);
    glBegin(GL_LINES);
        int i=0;
        for(int j=0;j<(All_curve[i].number_points-1);j++)
        {
            GLfloat point1[ ] = {All_curve[i].ControlPoints[j].x,All_curve[i].ControlPoints[j].y};
            GLfloat point2[ ] = {All_curve[i].ControlPoints[j+1].x,All_curve[i].ControlPoints[j+1].y};
            glVertex2fv (point1);
            glVertex2fv (point2);
        }
    glEnd();
    }
    
    if(show_control_point == 1)
    {
    //control points
    glColor3f(0, 0, 1);
    glBegin(GL_POINTS);
        int i=0;
        for(int j=1;j<(All_curve[i].number_points-1);j++)
        {
            glVertex2f(All_curve[i].ControlPoints[j].x, All_curve[i].ControlPoints[j].y);
            glPointSize(10*pixel_size);
        }
    glEnd();
    
    //head point
    glColor3f(1, 1, 0);
    glBegin(GL_POINTS);
        
        glVertex2f(All_curve[i].ControlPoints[0].x, All_curve[i].ControlPoints[0].y);
        glPointSize(15*pixel_size);
    
    glEnd();
    
    //head point
    glColor3f(1, 0, 1);
    glBegin(GL_POINTS);
    
        glVertex2f(All_curve[i].ControlPoints[(All_curve[i].number_points-1)].x, All_curve[i].ControlPoints[(All_curve[i].number_points-1)].y);
        glPointSize(7*pixel_size);
    
    glEnd();
    }
    
    
    //curve2
    if(show_curve_2 == 1)
        {
        //curve
            glColor3f(0, 1, 0);
            glBegin(GL_LINES);
            int i=1;
                for(int j=0;j<All_curve[i].resolution;j++)
                {
    //            cout<<All_curve[i].OutputPoints[j].x<<endl;
                    GLfloat point1[ ] = {All_curve[i].OutputPoints[j].x,All_curve[i].OutputPoints[j].y};
                    GLfloat point2[ ] = {All_curve[i].OutputPoints[j+1].x,All_curve[i].OutputPoints[j+1].y};
                    glVertex2fv (point1);
                    glVertex2fv (point2);
                    
                }
            glEnd();
        }
        
        if(show_line_segments_2 == 1)
        {
        //control Line
        glColor3f(1, 0, 0);
        glBegin(GL_LINES);
            int i=1;
            for(int j=0;j<(All_curve[i].number_points-1);j++)
            {
                GLfloat point1[ ] = {All_curve[i].ControlPoints[j].x,All_curve[i].ControlPoints[j].y};
                GLfloat point2[ ] = {All_curve[i].ControlPoints[j+1].x,All_curve[i].ControlPoints[j+1].y};
                glVertex2fv (point1);
                glVertex2fv (point2);
            }
        glEnd();
        }
        
        if(show_control_point_2 == 1)
        {
        //control points
        glColor3f(0, 0, 1);
        glBegin(GL_POINTS);
            int i=1;
            for(int j=1;j<(All_curve[i].number_points-1);j++)
            {
                glVertex2f(All_curve[i].ControlPoints[j].x, All_curve[i].ControlPoints[j].y);
                glPointSize(10*pixel_size);
            }
        glEnd();
        
        //head point
        glColor3f(1, 1, 0);
        glBegin(GL_POINTS);
            
            glVertex2f(All_curve[i].ControlPoints[0].x, All_curve[i].ControlPoints[0].y);
            glPointSize(15*pixel_size);
        
        glEnd();
        
        //head point
        glColor3f(1, 0, 1);
        glBegin(GL_POINTS);
        
            glVertex2f(All_curve[i].ControlPoints[(All_curve[i].number_points-1)].x, All_curve[i].ControlPoints[(All_curve[i].number_points-1)].y);
            glPointSize(7*pixel_size);
        
        glEnd();
        }
    
    
    if(Bezier_op == 1)
    {
        if(button_kind ==0)
            {
                move_sign_i=-1;
                move_sign_j=-1;
        //        cout<<"1"<<endl;
        //        cout<<hit_pos_x<<'\t'<<hit_pos_y<<endl;
                for(int i=0;i<num_curves;i++)
                    for(int j=0;j<All_curve[i].number_points;j++)
                    {
                       
                        if((hit_pos_x>(All_curve[i].ControlPoints[j].x-2))&&(hit_pos_x<(All_curve[i].ControlPoints[j].x+2))&&(hit_pos_y>(All_curve[i].ControlPoints[j].y-2))&&(hit_pos_y<(All_curve[i].ControlPoints[j].y+2)))
                        {
        //                    cout<<"special"<<endl;
                            move_sign_i = i;
                            move_sign_j = j;
                        }
                        
                    }
                button_kind = -1;
        //        cout<<move_sign_i<<'\t'<<move_sign_j<<endl;
            }
            if(button_kind == 3)
            {
        //        cout<<"2"<<endl;
        //        cout<<move_sign_i<<'\t'<<move_sign_j<<endl;
                if((move_sign_i!=-1)&&(move_sign_j!=-1))
                {
                    All_curve[move_sign_i].ControlPoints[move_sign_j].x = move_pos_x;
                    All_curve[move_sign_i].ControlPoints[move_sign_j].y = move_pos_y;
                }
                button_kind = -1;
            }
            for(int i=0;i<num_curves;i++)
            {
                All_curve[i].update();
            }
    }
    
    if(Bezier_op ==2)
    {
        if(button_kind == 0)
        {
            if((hit_pos_x!=-1)&&(hit_pos_y != -1))
            {
            
            
                if((All_curve[0].ControlPoints[(All_curve[0].number_points-1)].x != hit_pos_x)&&
                             (All_curve[0].ControlPoints[(All_curve[0].number_points-1)].y != hit_pos_y))
                {
                All_curve[0].number_points++;
                All_curve[0].ControlPoints[(All_curve[0].number_points-1)].x = hit_pos_x;
                All_curve[0].ControlPoints[(All_curve[0].number_points-1)].y = hit_pos_y;
//                cout<<All_curve[i].ControlPoints[(All_curve[i].number_points-1)].x<<'\t'<<All_curve[i].ControlPoints[(All_curve[i].number_points-1)].y<<endl;
                }
            
            button_kind = -1;
            }
        }
        
//        for(int i=0;i<num_curves;i++)
//        {
            All_curve[0].update();
//        }
    }
    
    if (Bezier_op == 3)
    {
        if (button_kind == 0)
        {
            if((hit_pos_x!=-1)&&(hit_pos_y != -1))
            {
            
//            for(int i=0;i<num_curves;i++)
//            {
                All_curve[0].add_head(hit_pos_x, hit_pos_y);
//            }
            button_kind = -1;
            }
        }
    }
    
    if(Bezier_op == 4)
    {
        if(button_kind ==0)
            {
                move_sign_i=-1;
                move_sign_j=-1;
        //        cout<<"1"<<endl;
        //        cout<<hit_pos_x<<'\t'<<hit_pos_y<<endl;
                for(int i=0;i<num_curves;i++)
                    for(int j=0;j<All_curve[i].number_points;j++)
                    {
                       
                        if((hit_pos_x>(All_curve[i].ControlPoints[j].x-2))&&(hit_pos_x<(All_curve[i].ControlPoints[j].x+2))&&(hit_pos_y>(All_curve[i].ControlPoints[j].y-2))&&(hit_pos_y<(All_curve[i].ControlPoints[j].y+2)))
                        {
        //                    cout<<"special"<<endl;
                            move_sign_i = i;
                            move_sign_j = j;
                        }
                        
                    }
                button_kind = -1;
                if((move_sign_i!=-1)&&(move_sign_j!=-1))
                    All_curve[move_sign_i].delete_point(move_sign_j);
        
            }
    }
    
    if(Bezier_op == 5)
    {
        if(insert_hit==1)
        {
            if(button_kind ==0)
            {
                move_sign_i=-1;
                move_sign_j=-1;
        //        cout<<"1"<<endl;
        //        cout<<hit_pos_x<<'\t'<<hit_pos_y<<endl;
                for(int i=0;i<num_curves;i++)
                    for(int j=0;j<All_curve[i].number_points;j++)
                    {
                       
                        if((hit_pos_x>(All_curve[i].ControlPoints[j].x-2))&&(hit_pos_x<(All_curve[i].ControlPoints[j].x+2))&&(hit_pos_y>(All_curve[i].ControlPoints[j].y-2))&&(hit_pos_y<(All_curve[i].ControlPoints[j].y+2)))
                        {
        //                    cout<<"special"<<endl;
                            move_sign_i = i;
                            move_sign_j = j;
                        }
                        
                    }
                if((move_sign_i!=-1)&&(move_sign_j!=-1))
                {
                    All_curve[move_sign_i].insert_point(move_sign_j);
                    insert_hit = 0;
                }
                button_kind = -1;
            }
        }
    }
    if(Bezier_op ==7)
        {
            if(button_kind == 0)
            {
                if((hit_pos_x!=-1)&&(hit_pos_y != -1))
                {
                
                
                    if((All_curve[1].ControlPoints[(All_curve[1].number_points-1)].x != hit_pos_x)&&
                                 (All_curve[1].ControlPoints[(All_curve[1].number_points-1)].y != hit_pos_y))
                    {
                    All_curve[1].number_points++;
                    All_curve[1].ControlPoints[(All_curve[1].number_points-1)].x = hit_pos_x;
                    All_curve[1].ControlPoints[(All_curve[1].number_points-1)].y = hit_pos_y;
    //                cout<<All_curve[i].ControlPoints[(All_curve[i].number_points-1)].x<<'\t'<<All_curve[i].ControlPoints[(All_curve[i].number_points-1)].y<<endl;
                    }
                
                button_kind = -1;
                }
            }
            
    //        for(int i=0;i<num_curves;i++)
    //        {
                All_curve[1].update();
    //        }
        }
        
        if (Bezier_op == 8)
        {
            if (button_kind == 0)
            {
                if((hit_pos_x!=-1)&&(hit_pos_y != -1))
                {
                
    //            for(int i=0;i<num_curves;i++)
    //            {
                    All_curve[1].add_head(hit_pos_x, hit_pos_y);
    //            }
                button_kind = -1;
                }
            }
        }
    
    
    
    
    
    
    
    //B_curve
    if(show_B_curve == 1)
        {
        //curve
            glColor3f(0, 1, 0);
            glBegin(GL_LINES);
            for(int i=0;i<num_B_curves;i++)
                for(int p=0;p<(All_B_curve[i].num_control_points-All_B_curve[i].order_k+1);p++)
                    for(int j=0;j<All_B_curve[i].resolution;j++)
                    {
    //            cout<<All_curve[i].OutputPoints[j].x<<endl;
                        GLfloat point1[ ] = {All_B_curve[i].OutputPoints[p][j].x,All_B_curve[i].OutputPoints[p][j].y};
                        GLfloat point2[ ] = {All_B_curve[i].OutputPoints[p][j+1].x,All_B_curve[i].OutputPoints[p][j+1].y};
                        glVertex2fv (point1);
                        glVertex2fv (point2);
                    }
            glEnd();
        }
        
        if(show_B_line_segments == 1)
        {
        //control Line
        glColor3f(1, 0, 0);
        glBegin(GL_LINES);
        for(int i=0;i<num_B_curves;i++)
            for(int j=0;j<(All_B_curve[i].num_control_points-1);j++)
            {
                GLfloat point1[ ] = {All_B_curve[i].ControlPoints[j].x,All_B_curve[i].ControlPoints[j].y};
                GLfloat point2[ ] = {All_B_curve[i].ControlPoints[j+1].x,All_B_curve[i].ControlPoints[j+1].y};
                glVertex2fv (point1);
                glVertex2fv (point2);
            }
        glEnd();
        }
        
        if(show_B_control_point == 1)
        {
        //control points
        glColor3f(0, 0, 1);
        glBegin(GL_POINTS);
        for(int i=0;i<num_B_curves;i++)
            for(int j=1;j<(All_B_curve[i].num_control_points-1);j++)
            {
                glVertex2f(All_B_curve[i].ControlPoints[j].x,All_B_curve[i].ControlPoints[j].y);
                glPointSize(10*pixel_size);
            }
        glEnd();
        
        //head point
        glColor3f(1, 1, 0);
        glBegin(GL_POINTS);
        for(int i=0;i<num_B_curves;i++)
        {
            glVertex2f(All_B_curve[i].ControlPoints[0].x,All_B_curve[i].ControlPoints[0].y);
            glPointSize(15*pixel_size);
        }
        glEnd();
        
        //head point
        glColor3f(1, 0, 1);
        glBegin(GL_POINTS);
        for(int i=0;i<num_B_curves;i++)
        {
            glVertex2f(All_B_curve[i].ControlPoints[All_B_curve[i].num_control_points-1].x,All_B_curve[i].ControlPoints[All_B_curve[i].num_control_points-1].y);
            glPointSize(15*pixel_size);
        }
        glEnd();
        }
    
    if(B_Spine_op == 1)
    {
        if(button_kind ==0)
            {
                move_sign_i=-1;
                move_sign_j=-1;
        //        cout<<"1"<<endl;
        //        cout<<hit_pos_x<<'\t'<<hit_pos_y<<endl;
                for(int i=0;i<num_B_curves;i++)
                    for(int j=0;j<All_B_curve[i].num_control_points;j++)
                    {
                       
                        if((hit_pos_x>(All_B_curve[i].ControlPoints[j].x-2))&&(hit_pos_x<(All_B_curve[i].ControlPoints[j].x+2))&&(hit_pos_y>(All_B_curve[i].ControlPoints[j].y-2))&&(hit_pos_y<(All_B_curve[i].ControlPoints[j].y+2)))
                        {
        //                    cout<<"special"<<endl;
                            move_sign_i = i;
                            move_sign_j = j;
                        }
                        
                    }
                button_kind = -1;
        //        cout<<move_sign_i<<'\t'<<move_sign_j<<endl;
            }
            if(button_kind == 3)
            {
        //        cout<<"2"<<endl;
        //        cout<<move_sign_i<<'\t'<<move_sign_j<<endl;
                if((move_sign_i!=-1)&&(move_sign_j!=-1))
                {
                    All_B_curve[move_sign_i].ControlPoints[move_sign_j].x = move_pos_x;
                    All_B_curve[move_sign_i].ControlPoints[move_sign_j].y = move_pos_y;
//                    for(int p=0;p<(All_B_curve[move_sign_i].num_control_points-All_B_curve[move_sign_i].order_k+1);p++)
//                        delete [] All_B_curve[move_sign_i].OutputPoints[p];
//                    delete [] All_B_curve[move_sign_i].OutputPoints;
                }
                button_kind = -1;
            }
        if(move_sign_i!=-1)
            All_B_curve[move_sign_i].update();
            
    }
    
    if(B_Spine_op ==2)
        {
            
            if(button_kind == 0)
            {
                if((hit_pos_x!=-1)&&(hit_pos_y != -1))
                {
                
                for(int i=0;i<num_B_curves;i++)
                {
                    if((All_B_curve[i].ControlPoints[(All_B_curve[i].num_control_points-1)].x != hit_pos_x)&&
                                 (All_B_curve[i].ControlPoints[(All_B_curve[i].num_control_points-1)].y != hit_pos_y))
                    {
                    All_B_curve[i].num_control_points++;
                        order_k_B_spinner->set_int_limits(2,All_B_curve[0].num_control_points,GLUI_LIMIT_CLAMP);
                    All_B_curve[i].ControlPoints[(All_B_curve[i].num_control_points-1)].x = hit_pos_x;
                    All_B_curve[i].ControlPoints[(All_B_curve[i].num_control_points-1)].y = hit_pos_y;
    //                cout<<All_curve[i].ControlPoints[(All_curve[i].number_points-1)].x<<'\t'<<All_curve[i].ControlPoints[(All_curve[i].number_points-1)].y<<endl;
                    }
//                    for(int p=0;p<(All_B_curve[i].num_control_points-All_B_curve[i].order_k+1);p++)
//                        delete [] All_B_curve[i].OutputPoints[p];
//                    delete [] All_B_curve[i].OutputPoints;
                    All_B_curve[i].update();
                }
                button_kind = -1;
                }
            }
        }
    
    if (B_Spine_op == 3)
    {
        if (button_kind == 0)
        {
            if((hit_pos_x!=-1)&&(hit_pos_y != -1))
            {
            
            for(int i=0;i<num_B_curves;i++)
            {
                All_B_curve[i].add_head(hit_pos_x, hit_pos_y);
                order_k_B_spinner->set_int_limits(2,All_B_curve[0].num_control_points,GLUI_LIMIT_CLAMP);
            }
            button_kind = -1;
            }
        }
    }
    
    if(B_Spine_op == 4)
    {
        if(button_kind ==0)
            {
                move_sign_i=-1;
                move_sign_j=-1;
        //        cout<<"1"<<endl;
        //        cout<<hit_pos_x<<'\t'<<hit_pos_y<<endl;
                for(int i=0;i<num_B_curves;i++)
                    for(int j=0;j<All_B_curve[i].num_control_points;j++)
                    {
                       
                        if((hit_pos_x>(All_B_curve[i].ControlPoints[j].x-2))&&(hit_pos_x<(All_B_curve[i].ControlPoints[j].x+2))&&(hit_pos_y>(All_B_curve[i].ControlPoints[j].y-2))&&(hit_pos_y<(All_B_curve[i].ControlPoints[j].y+2)))
                        {
        //                    cout<<"special"<<endl;
                            move_sign_i = i;
                            move_sign_j = j;
                        }
                        
                    }
                button_kind = -1;
                if((move_sign_i!=-1)&&(move_sign_j!=-1))
                {
                    All_B_curve[move_sign_i].delete_point(move_sign_j);
                order_k_B_spinner->set_int_limits(2,All_B_curve[0].num_control_points,GLUI_LIMIT_CLAMP);
                }
        
            }
    }
    
    if(B_Spine_op == 5)
    {
        if(insert_B_hit==1)
        {
            if(button_kind ==0)
            {
                move_sign_i=-1;
                move_sign_j=-1;
        //        cout<<"1"<<endl;
        //        cout<<hit_pos_x<<'\t'<<hit_pos_y<<endl;
                for(int i=0;i<num_B_curves;i++)
                    for(int j=0;j<All_B_curve[i].num_control_points;j++)
                    {
                       
                        if((hit_pos_x>(All_B_curve[i].ControlPoints[j].x-2))&&(hit_pos_x<(All_B_curve[i].ControlPoints[j].x+2))&&(hit_pos_y>(All_B_curve[i].ControlPoints[j].y-2))&&(hit_pos_y<(All_B_curve[i].ControlPoints[j].y+2)))
                        {
        //                    cout<<"special"<<endl;
                            move_sign_i = i;
                            move_sign_j = j;
                        }
                        
                    }
                if((move_sign_i!=-1)&&(move_sign_j!=-1))
                {
                    All_B_curve[move_sign_i].insert_point(move_sign_j);
                    order_k_B_spinner->set_int_limits(2,All_B_curve[0].num_control_points,GLUI_LIMIT_CLAMP);
                    insert_B_hit = 0;
                }
                
                button_kind = -1;
            }
        }
        
    }
    
    
    
    
    
    //blits the current opengl framebuffer on the screen
    glutSwapBuffers();
    //checks for opengl errors
    glutPostRedisplay();
}
void Init()
{
  /* Set clear color to white */
  glClearColor(0,0,0,0);
  /* Set fill color to black */
  /* glViewport(0 , 0 , 640 , 480); */
  glMatrixMode(GL_PROJECTION);
  /* glLoadIdentity(); */
  gluOrtho2D(0, win_width , 0 , win_height);
}
void reshape(int reshape_width, int reshape_height)
{
    /*set up projection matrix to define the view port*/
    //update the ne window width and height
    win_width = reshape_width;
    win_height = reshape_height;
    
    //creates a rendering area across the window
    glViewport(0,0,reshape_width,reshape_height);
    // up an orthogonal projection matrix so that
    // the pixel space is mapped to the grid space
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,width,0,length,-10,10);
    
    //clear the modelview matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    //set pixel size based on width, if the aspect ratio
    //changes this hack won't work as well
    pixel_size = reshape_width/(float)width;
    
    //set pixel size relative to the grid cell size
    glPointSize(pixel_size);
    //check for opengl errors
}

void ReadFile()
{
    cout<<"--------------------ATTENTION-----------------------------------"<<endl;
    cout<<"Please Read the README.txt before any operation."<<endl;
    cout<<"----------------------------------------------------------------"<<endl;
    cout<<"Please type in the file address. Input like 'test_curve.txt' "<<endl;
    cin>>File_Address;
    
    std::ifstream infile;
    infile.open(File_Address);
    
    infile>>num_curves;
    All_curve = new Curve[num_curves];
    for(int i=0;i<num_curves;i++)
    {
        infile>>All_curve[i].number_points;
        infile>>All_curve[i].resolution;
        
        for(int j=0;j<All_curve[i].number_points;j++)
        {
            infile>>All_curve[i].ControlPoints[j].x;
            infile>>All_curve[i].ControlPoints[j].y;
        }
        All_curve[i].update();
    }
    
    infile>>num_B_curves;
    All_B_curve = new B_Spine_Curve[num_B_curves];
    for(int i=0;i<num_B_curves;i++)
    {
        infile>>All_B_curve[i].num_control_points;
        infile>>All_B_curve[i].resolution;
        
        for(int j=0;j<All_B_curve[i].num_control_points;j++)
        {
            infile>>All_B_curve[i].ControlPoints[j].x;
            infile>>All_B_curve[i].ControlPoints[j].y;
        }
        All_B_curve[i].update();
    }
    
    
    
}

void SaveFile(int file_save)
{
    if(file_save==1)
    {
        std::ofstream outfile;
        outfile.open("/Users/bruce/Documents/Output_file.txt");
    
    outfile<<num_curves<<endl;
        outfile<<endl;
    for(int i=0;i<num_curves;i++)
    {
        outfile<<All_curve[i].number_points<<endl;
        outfile<<All_curve[i].resolution<<endl;
        outfile<<endl;
        for(int j=0;j<All_curve[i].number_points;j++)
        {
            outfile<<All_curve[i].ControlPoints[j].x<<'\t';
            outfile<<All_curve[i].ControlPoints[j].y<<endl;
        }
        outfile<<endl;
    }
    
    outfile<<num_B_curves<<endl;
        outfile<<endl;
    for(int i=0;i<num_B_curves;i++)
    {
        outfile<<All_B_curve[i].num_control_points<<endl;
        outfile<<All_B_curve[i].resolution<<endl;
        outfile<<endl;
        
        for(int j=0;j<All_B_curve[i].num_control_points;j++)
        {
            outfile<<All_B_curve[i].ControlPoints[j].x<<'\t';
            outfile<<All_B_curve[i].ControlPoints[j].y<<endl;
        }
        outfile<<endl;
    }
        file_save = 0;
    }
    
    
    
}



int main(int argc, char **argv)
{
    ReadFile();
//    cout<<"Input the number of curves"<<endl;
//    cin>>num_curves;
//    num_curves = 1;
//    All_curve = new Curve[1];
//    All_B_curve = new B_Spine_Curve[1];

    /* Initialise GLUT library */
    glutInit(&argc,argv);
    /* Set the initial display mode */
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    /* Set the initial window position and size */
    glutInitWindowPosition(100,100);
    glutInitWindowSize(win_width,win_height);
    glutCreateWindow("Project4");
    /* Initialize drawing colors */
    Init();
    /* Call the displaying function */
    glutDisplayFunc(draw_curve);
    glutReshapeFunc(reshape);
    glutMouseFunc(mouse_hit);
    glutMotionFunc(mouse_move);
    /* Keep displaying untill the program is closed */
    //glutKeyboardFunc(key);
    
    
    //glui window for Bezier
    GLUI *glui = GLUI_Master.create_glui("Bezier Interface",0);
    GLUI_Panel *panel_Bezier = new GLUI_Panel(glui,"Bezier Curve Operation",GLUI_PANEL_EMBOSSED);
    GLUI_Panel *panel_Bezier_op = new GLUI_Panel(panel_Bezier,"",GLUI_PANEL_NONE);
    new GLUI_Button(panel_Bezier_op,"MOVE POINTS",1,control_cb);
    new GLUI_Button(panel_Bezier_op,"CURVE 1: ADD POINT TO THE TAIL",2,control_cb);
    new GLUI_Button(panel_Bezier_op,"CURVE 1: ADD POINT TO THE HEAD",3,control_cb);
    new GLUI_Button(panel_Bezier_op,"CURVE 2: ADD POINT TO THE TAIL",7,control_cb);
    new GLUI_Button(panel_Bezier_op,"CURVE 2: ADD POINT TO THE HEAD",8,control_cb);
    new GLUI_Button(panel_Bezier_op,"DELETE POINT",4,control_cb);
    new GLUI_Button(panel_Bezier_op,"INSERT POINT",5,control_cb);
    glui->add_column_to_panel(panel_Bezier,true);
    GLUI_Spinner *resolution_spinner = new GLUI_Spinner(panel_Bezier,"CURVE1 : RESOLUTION",GLUI_SPINNER_INT,&All_curve[0].resolution,6,control_cb);
    resolution_spinner->set_int_limits(1, 100,GLUI_LIMIT_CLAMP);
    GLUI_Spinner *resolution_spinner_2 = new GLUI_Spinner(panel_Bezier,"CURVE2 : RESOLUTION",GLUI_SPINNER_INT,&All_curve[1].resolution,9,control_cb);
    resolution_spinner_2->set_int_limits(1, 100,GLUI_LIMIT_CLAMP);
    new GLUI_Checkbox(panel_Bezier,"SHOW CURVE 1",&show_curve);
    new GLUI_Checkbox(panel_Bezier,"SHOW CURVE 1 CONTROL POINTS",&show_control_point);
    new GLUI_Checkbox(panel_Bezier,"SHOW CURVE 1 LINE SEGMENTS",&show_line_segments);
    new GLUI_Checkbox(panel_Bezier,"SHOW CURVE 2",&show_curve_2);
    new GLUI_Checkbox(panel_Bezier,"SHOW CURVE 2 CONTROL POINTS",&show_control_point_2);
    new GLUI_Checkbox(panel_Bezier,"SHOW CURVE 2 LINE SEGMENTS",&show_line_segments_2);
    
    //glui window for B-Spine
    gluiB1 = GLUI_Master.create_glui("B-Spine Interface",0);
    GLUI_Panel *panel_B_Spine = new GLUI_Panel(gluiB1,"B-Spine Curve Operation",GLUI_PANEL_EMBOSSED);
    GLUI_Panel *panel_B_Spine_op = new GLUI_Panel(panel_B_Spine,"",GLUI_PANEL_NONE);
    new GLUI_Button(panel_B_Spine_op,"MOVE POINTS",1,control_B_Spine);
    new GLUI_Button(panel_B_Spine_op,"ADD POINT TO THE TAIL",2,control_B_Spine);
    new GLUI_Button(panel_B_Spine_op,"ADD POINT TO THE HEAD",3,control_B_Spine);
    new GLUI_Button(panel_B_Spine_op,"DELETE POINT",4,control_B_Spine);
    new GLUI_Button(panel_B_Spine_op,"INSERT POINT",5,control_B_Spine);
    glui->add_column_to_panel(panel_B_Spine,true);
    GLUI_Spinner *resolution_B_spinner = new GLUI_Spinner(panel_B_Spine,"RESOLUTION",GLUI_SPINNER_INT,&All_B_curve[0].resolution,6,control_B_Spine);
    resolution_B_spinner->set_int_limits(1, 100,GLUI_LIMIT_CLAMP);
    order_k_B_spinner = new GLUI_Spinner(panel_B_Spine,"NUM_ORDER_K",GLUI_SPINNER_INT,&All_B_curve[0].order_k,7,control_B_Spine);
    order_k_B_spinner->set_int_limits(2,All_B_curve[0].num_control_points,GLUI_LIMIT_CLAMP);
    new GLUI_Checkbox(panel_B_Spine,"SHOW CURVE",&show_B_curve);
    new GLUI_Checkbox(panel_B_Spine,"SHOW CONTROL POINTS",&show_B_control_point);
    new GLUI_Checkbox(panel_B_Spine,"SHOW LINE SEGMENTS",&show_B_line_segments);
    open_adjust_window = new GLUI_Button(panel_B_Spine,"ADJUST KNOT",1,open_adjust_knot_window);
    
    GLUI *glui_save_quit = GLUI_Master.create_glui("SAVE AND QUIT",0);
    new GLUI_Button(glui_save_quit,"SAVE ALL",1,SaveFile);
    new GLUI_Button(glui_save_quit,"QUIT",0,(GLUI_Update_CB)exit );
    
    
    glutMainLoop();
    
    delete [] All_curve;
}
